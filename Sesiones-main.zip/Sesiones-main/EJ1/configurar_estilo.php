<!DOCTYPE html>
<html>
<head>
    <title>Configuración de Estilo CSS</title>
</head>
<body>
    <h1>Configuración de Estilo CSS</h1>
    <form method="post" action="guardar_estilo.php">
        <label for="estilo">Seleccione un estilo:</label>
        <select name="estilo" id="estilo">
            <option value="estilo-claro">Claro</option>
            <option value="noche-claro">Noche Clara</option>
            <option value="modo-oscuro">Noche</option>
        </select>
        <input type="submit" value="Guardar Estilo">
    </form>
    <br>
    <a href="indexP7Ej1.php">Volver a la página principal</a>
</body>
</html>
