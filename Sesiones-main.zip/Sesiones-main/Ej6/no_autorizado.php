<!DOCTYPE html>
<html>
<head>
    <title>No Autorizado</title>
</head>
<body>
    <h1>No puedes visitar esta página.</h1>
</body>
</html>
