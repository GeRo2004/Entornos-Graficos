<?php
session_start();
session_destroy();
echo "La sesión se ha cerrado. <a href='EJ 4a.php'>Volver a la Página 1</a>";
?>