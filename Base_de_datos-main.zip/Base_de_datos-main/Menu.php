<!DOCTYPE html>
<html>
<head>
    <title>ABML Capitales</title>
</head>
<body>
    <h1>ABML de Capitales</h1>
    <ul>
        <li><a href="alta.php">Agregar Ciudad</a></li>
        <li><a href="modificacion.php">Modificar Ciudad</a></li>
        <li><a href="baja.php">Eliminar Ciudad</a></li>
        <li><a href="listado.php">Listar Ciudades</a></li>
        <li><a href="listado_pag.php">Listar Ciudades con paginacion</a></li>
    </ul>
</body>
</html>
